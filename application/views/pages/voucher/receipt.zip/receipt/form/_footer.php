<script src="<?php echo assets('dist/js/voucher/receipt.js?v=2')?>"></script>
<script type="text/javascript">
    get_payment_mode_data();
    get_transaction();
</script>